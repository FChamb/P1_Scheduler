//
// Created by Finnegan Chamberlain on 10/2/24.
//
#pragma once

#include <stacsos/kernel/sched/alg/scheduling-algorithm.h>
#include <stacsos/list.h>
#include <stacsos/kernel/sched/schedulable-entity.h>

namespace stacsos::kernel::sched::alg {
    /**
     * Priority implementation. To add to the runqueue_, a for loop first finds if
     * the current task has a higher or lower priority. If it is higher the task
     * is added first. Otherwise it continues looking for a spot. Remove from
     * runqueue_ just removes the item.
     */
    class priority : public scheduling_algorithm {
    public:
        virtual void add_to_runqueue(tcb &tcb) override {
            auto queue = runqueue_.begin();
            for (; queue != runqueue_.end(); ++queue) {
                if ((*queue)->entity->priority() > tcb.entity->priority()) {
                    break;
                }
            }
            runqueue_.insert(queue, &tcb);
        };
        virtual void remove_from_runqueue(tcb &tcb) override { runqueue_.remove(&tcb); };
        virtual tcb *select_next_task(tcb *current) override;
        virtual const char *name() const { return "priority"; }

    private:
        list<tcb *> runqueue_;
    };

} // namespace stacsos::kernel::sched::alg
