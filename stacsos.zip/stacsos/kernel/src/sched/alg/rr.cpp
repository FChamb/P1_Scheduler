/* SPDX-License-Identifier: MIT */

/* StACSOS - Kernel
 *
 * Copyright (c) University of St Andrews 2024
 * Tom Spink <tcs6@st-andrews.ac.uk>
 */
#include <stacsos/kernel/sched/alg/rr.h>

// *** COURSEWORK NOTE *** //
// This will be where you are implementing your round-robin scheduling algorithm.
// Please edit this file in any way you see fit.  You may also edit the rr.h
// header file.

using namespace stacsos::kernel::sched;
using namespace stacsos::kernel::sched::alg;

/**
 * I commented out the below two functions as they are instead defined in the header
 * file. I asked the lecturer about this and he said in C++ we define a lot more in the
 * header file.
 */
//void round_robin::add_to_runqueue(tcb &tcb) { robinQueue_.append(&tcb); }

//void round_robin::remove_from_runqueue(tcb &tcb) { robinQueue_.remove(&tcb); }

/*
 * The implementation for round-robin select next task first defines a candidate
 * as a null pointer. Then the program uses a check to see if the runqueue is empty
 * and returns the null pointer if so. If not, the program dequeues the first task
 * appends it to the front and returns it.
 */
tcb *round_robin::select_next_task(tcb *current) {
    tcb *candidate = nullptr;
    if (runqueue_.empty()) {
        return candidate;
    }
    candidate = runqueue_.dequeue();
    runqueue_.append(candidate);
    return candidate;
}