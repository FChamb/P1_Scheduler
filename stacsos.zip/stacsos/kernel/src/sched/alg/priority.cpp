//
// Created by Finnegan Chamberlain on 10/4/24.
//
#include <stacsos/kernel/sched/alg/priority.h>

using namespace stacsos::kernel::sched;
using namespace stacsos::kernel::sched::alg;

/**
 * Select next task for priority which does something similar to round
 * robin but instead looks at priority via the functions in the header file.
 *
 * I have not fully tested this implementation. I know that the OS boots up and
 * seems to work. Several other files were changed/added to in order to make this
 * work with the command line arguments. Those files have been provided in the .tar
 * submission.
 */
tcb *priority::select_next_task(tcb *current) {
    tcb *candidate = nullptr;
    if (runqueue_.empty()) {
        return candidate;
    }

    candidate = runqueue_.first();
    runqueue_.remove(candidate);
    return candidate;
}