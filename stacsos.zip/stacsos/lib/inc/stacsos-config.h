#pragma once

#define USE_FSGSBASE
